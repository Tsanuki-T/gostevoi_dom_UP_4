const stay = document.querySelector('#stay');
if (stay) {
  const money = new Intl.NumberFormat('ru-RU', {style:'currency', currency:'RUB', maximumFractionDigits:0});
  const date = (value) => new Date(value + 'T00:00:00Z');
  stay.addEventListener('submit', (event) => {
    event.preventDefault();
    const values = new FormData(stay);
    const start = date(values.get('arrive'));
    const end = date(values.get('depart'));
    const nights = (end - start) / 86400000;
    const result = document.querySelector('#estimate-result');
    if (!(nights > 0)) {
      result.textContent = 'Дата выезда должна быть позже даты заезда.';
      return;
    }
    const windows = [['2027-04-01','2027-06-01'], ['2027-09-15','2027-11-01']];
    const discount = nights >= 2 && windows.some(([from,to]) => start >= date(from) && end <= date(to));
    const total = nights * Number(values.get('room')) * (discount ? 0.9 : 1);
    result.textContent = 'Ночей: ' + nights + '. Стоимость: ' + money.format(total) + (discount ? ' со скидкой 10%.' : ' по обычной цене.');
  });
}
const feedback = document.querySelector('#feedback');
if (feedback) {
  const key = 'chalda-feedback-draft';
  const area = feedback.elements.question;
  const result = document.querySelector('#feedback-result');
  try { area.value = localStorage.getItem(key) || ''; } catch {}
  feedback.addEventListener('submit', (event) => {
    event.preventDefault();
    const question = area.value.trim();
    if (!question) {
      result.textContent = 'Напишите вопрос о поездке.';
      return;
    }
    try {
      localStorage.setItem(key, question);
      result.textContent = 'Черновик сохранён в этом браузере.';
    } catch {
      result.textContent = 'Браузер не разрешил сохранить черновик. Скопируйте текст из поля.';
    }
  });
}
